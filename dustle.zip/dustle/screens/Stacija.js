import React, { useState, useEffect, ComponentProps, Component } from 'react';
import 'react-native-gesture-handler';
import { createStackNavigator } from '@react-navigation/stack';
import { Image, Platform, Text, View, StyleSheet, Button, Alert, ListView, TouchableOpacity, FlatList, Picker, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import logo from '../assets/dus1.png';
import * as Location from 'expo-location';
import { Constants } from 'expo';

const Stack = createStackNavigator();

export default class App extends Component {
 constructor(props) {
    super(props)
    this.stacijas = ['Neste', 'CirkleK', 'Viada', 'Latvijas Nafta','LPG','Virši','Gotika Auto','KOOL','Astarte Nafta' ,'Metro'];
    this.state = {
        secondStacija: null,
    }
  }
  
  render() {
    return (
      <ScrollView style={styles.container}>
      <Image source={logo} style={styles.logo} /> 
        <Text style={styles.title}>
        DUS:
        </Text>
        <Picker
          style={styles.picker} itemStyle={styles.pickerItem}
          selectedValue={this.state.selectStacija}
          onValueChange={(itemValue) => this.setState({selectStacija: itemValue})}
        >
        <Picker.Item label="Neste" value="Neste" />
          <Picker.Item label="CirkleK" value="CirkleK" />
          <Picker.Item label="LPG" value="LPG" />
          <Picker.Item label="Viada" value="Viada" />
          <Picker.Item label="Latvijas Nafta" value="Latvijas Nafta" />
          <Picker.Item label="Virši" value="Virši" />
          <Picker.Item label="Gotika Auto" value="Gotika Auto" />
          <Picker.Item label="KOOL" value="KOOL" />
          <Picker.Item label="Astarte Nafta" value="Astarte Nafta" />
          <Picker.Item label="Metro" value="Metro" />
        </Picker>
        </ScrollView>
    );
  }}

  const styles = StyleSheet.create({
  container: {
     flex: 1,
    backgroundColor: '#1E90FF',
    padding: 8,  
  },
  title: {
    fontSize: 50,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
  picker: {
    width: 300,
    backgroundColor: '#F8F8FF',
    borderColor: 'black',
    

   },
 });