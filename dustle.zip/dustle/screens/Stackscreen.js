import * as React from 'react';
import { View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Map from '../screens/map.js';
import Veidi from '../screens/Veidi.js';
import Stacija from '../screens/Stacija.js';

function HomeScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Home Screen</Text>
    </View>
  );
}
const Stack = createStackNavigator();
function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Map" component={Map} />
        <Stack.Screen name="Veidi" component={Veidi} />
        <Stack.Screen name="Stacija" component={Stacija} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;