import React, { useState, useEffect, Component } from 'react';
import 'react-native-gesture-handler';
import { createStackNavigator } from '@react-navigation/stack';
import { Image, Platform, Text, View, StyleSheet, Button, Alert, ListView, TouchableOpacity, Picker, ScrollView, Dimensions } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import Constants from 'expo-constants';
import logo from '../assets/dus1.png';
import * as Location from 'expo-location';
import locationq from '../screens/location';
import Veidi from '../screens/Veidi.js';
import StackScreen from '../screens/Stackscreen';
import Stacija from '../screens/Stacija';
import MapView from 'react-native-maps';
import { Marker } from 'react-native-maps'


export default function App() {
  const[markers, setmarkers] = useState([
     {lat: 57.5317865, lon: 25.3938188, title: 'Neste1', description: "Rīgas iela 76, Valmiera - 95; eur 1.19"},
     {lat: 57.5317014,  lon: 25.4287964, title: 'Neste2', description: "Mazā Stacijas iela 14, Valmiera - 95; eur 1.19"}
    ])
   return (
    <View style={styles.container}>
      <MapView style={styles.mapView} showsUserLocation followsUserLocation showsPointsOfInterest={false}>
        {
          markers.map((marker) => (
            <Marker
              coordinate={{
                latitude: marker.lat,
                longitude: marker.lon
               }}
              title={marker.title}
              description={marker.description}
            />
          ))
        }
          <MapView.Marker
          title="Neste1"
            coordinate={{
            latitude: 57.5317865, 
            longitude: 25.3938188,
            }}
            />
             <MapView.Marker
          title="Neste2"
          coordinate={{
          latitude: 57.5317014,
          longitude: 25.4287964, 
           description: "Mazā Stacijas iela 14, Valmiera - 95; eur 1.19"
            
            }}
            />
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  mapView: {
    height: Dimensions.get('window').height, 
    width: Dimensions.get('window').width
  }
});
