import React, { useState, useEffect, ComponentProps, Component } from 'react';
import 'react-native-gesture-handler';
import { createStackNavigator } from '@react-navigation/stack';
import { Image, Platform, Text, View, StyleSheet, Button, Alert, ListView, TouchableOpacity, FlatList, Picker, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import logo from '../assets/dus1.png';
import * as Location from 'expo-location';
import { Constants } from 'expo';

const Stack = createStackNavigator();

export default class App extends Component {
  constructor(props) {
    super(props)
    this.veids = ['95', '98', 'LPG','Diesel'];
    this.state = {
        secondVeids: null,
    }
  }
  
  render() {
    return (
      <ScrollView style={styles.container}>
       <Image source={logo} style={styles.logo} /> 
        <Text style={styles.title}>
        Degvielas veids:
        </Text>
        <Picker
          style={styles.picker} itemStyle={styles.pickerItem}
          selectedValue={this.state.selectVeids}
          onValueChange={(itemValue) => this.setState({selectVeids: itemValue})}
         >
          <Picker.Item label="95" value="95" />
          <Picker.Item label="98" value="98" />
          <Picker.Item label="LPG" value="LPG" />
          <Picker.Item label="Disel" value="Disel" />
         
        </Picker>
         </ScrollView>
    );
  }}
  const styles = StyleSheet.create({
  container: {
     flex: 1,
    backgroundColor: '#1E90FF',
    padding: 8,
  
  },
  title: {
    fontSize: 50,
    fontWeight: 'bold',    
  },
  picker: {
    width: 300,
    backgroundColor: '#FFF0F0',
    borderColor: 'black',
    borderWidth: 1,
 },
 });
