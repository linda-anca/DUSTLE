import React, { useState, useEffect } from 'react';
import 'react-native-gesture-handler';
import { createStackNavigator } from '@react-navigation/stack';
import { Image, Platform, Text, View, StyleSheet, Button, Alert, ListView, TouchableOpacity, Picker, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import Constants from 'expo-constants';
import logo from './assets/dus1.png';
import * as Location from 'expo-location';
import locationq from './screens/location';
import Veidi from './screens/Veidi.js';
import StackScreen from './screens/Stackscreen';
import Stacija from './screens/Stacija.js';
import Map from './screens/map.js';

function HomeScreen({navigation}) {
  return (
   <ScrollView style={styles.container}>
        <View style={styles.box}>
      <Text style={styles.paragraph}>
      Dustle
      </Text>
      <Image source={logo} style={styles.logo} /> 
     </View>      
    <View style={styles.container1}>
    <View style={styles.box1}>
      <Button style={styles.button} title="Degvielas veids:" color='black' onPress={() =>{
      console.log(navigation);
        navigation.navigate("Veidi");}} />
      </View>
      <View style={styles.box1}>
      <Button style={styles.button} title="Uzpildes stacija:" color='black' onPress={() => {
      console.log(navigation);
        navigation.navigate("Stacija");}} />
      </View>
      <View style={styles.box1}>            
      <Button style={styles.button} title="Meklet pec atrasanas vietas" color='black' onPress={() => {
      console.log(navigation);
      navigation.navigate("Map");}}/> 
    </View>
    </View>
    </ScrollView>
  );}

const Stack = createStackNavigator();

export default function App() {

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="home" component={HomeScreen} />
        <Stack.Screen name="Map" component={Map} />
        <Stack.Screen name="Veidi" component={Veidi} />
        <Stack.Screen name="Stacija" component={Stacija} />
      </Stack.Navigator>
    </NavigationContainer>   
  );
}

const styles = StyleSheet.create({
  container: {
    
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#1E90FF',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    marginTop: 100,
    color: '#F8F8FF',
    fontSize: 70,
    fontWeight: 'bold',
    textAlign: 'center',
  },
 logo: {
   marginVertical:40,
   marginHorizontal:30,
   flexDirection: 'row',
   flex:1,
   justifyContent: 'center',
   alignItems: 'center',
    width: 314,
    height: 314,
    }, 
 box1: {
    margin: 14,
    backgroundColor: 'white',
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    fontcolor: "#000000",
  },
  container1: {
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#1E90FF',
    padding: 8,
  },
  });

